-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 15, 2024 at 02:16 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crms`
--

-- --------------------------------------------------------

--
-- Table structure for table `archiveclasses`
--

CREATE TABLE `archiveclasses` (
  `class_id` int(11) NOT NULL,
  `class_name` varchar(255) NOT NULL,
  `section_code` varchar(255) NOT NULL,
  `subject_code` varchar(255) NOT NULL,
  `time_deleted` timestamp NOT NULL DEFAULT current_timestamp(),
  `teachers_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `archiveclasses`
--

INSERT INTO `archiveclasses` (`class_id`, `class_name`, `section_code`, `subject_code`, `time_deleted`, `teachers_id`) VALUES
(12, 'joed', '1102', 'joed', '2024-12-01 06:33:33', 0),
(16, 'DBMS', '1101', 'IT 211', '2024-12-05 06:40:54', 0),
(17, 'OOP', '1103', 'CS 211', '2024-12-05 21:40:42', 1),
(18, 'DBMS', '1101', 'IT 211', '2024-12-05 21:46:23', 1),
(19, 'joed', '1101', 'CS 211', '2024-12-05 21:51:03', 1),
(20, 'DSA', '1103', 'CS 211', '2024-12-05 22:22:41', 1),
(22, 'slkdfkdf', '1104', 'CS 211', '2024-12-05 22:27:12', 1),
(21, 'jedkjasdfkj', '1103', 'IT 211', '2024-12-06 00:10:44', 1),
(24, 'joed', '1101', 'CS 211', '2024-12-06 00:16:39', 1),
(26, 'MATH 102', '2102', 'MATH 102', '2024-12-06 01:40:09', 8),
(31, 'Class', '2103', 'CS 211', '2024-12-07 05:07:34', 1),
(25, 'Class', '2102', 'CS 211', '2024-12-07 05:07:38', 1),
(23, 'Math - 101', '1104', 'CS 211', '2024-12-07 05:07:41', 1),
(33, 'CS 121 - BSIT 2101', '2102', 'CS 121', '2024-12-07 06:00:44', 1),
(47, 'GEd 104 - BSIT 2103', '2103', 'GEd 104', '2024-12-07 08:03:28', 1),
(48, 'GEd 104 - BSIT 2103', '2103', 'GEd 104', '2024-12-07 08:44:04', 1);

-- --------------------------------------------------------

--
-- Table structure for table `building`
--

CREATE TABLE `building` (
  `building_id` int(11) NOT NULL,
  `building_name` varchar(255) NOT NULL,
  `room_id` int(11) NOT NULL,
  `building_code` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `building`
--

INSERT INTO `building` (`building_id`, `building_name`, `room_id`, `building_code`) VALUES
(4, 'Higher Education Building\r\n', 0, 'HEB'),
(6, 'College of Teachers Education Building\r\n', 0, 'CTEB');

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--

CREATE TABLE `classes` (
  `class_id` int(11) NOT NULL,
  `class_name` varchar(255) NOT NULL,
  `section_code` int(11) DEFAULT NULL,
  `subject_code` varchar(50) NOT NULL,
  `teachers_id` int(11) DEFAULT NULL,
  `room_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `classes`
--

INSERT INTO `classes` (`class_id`, `class_name`, `section_code`, `subject_code`, `teachers_id`, `room_name`) VALUES
(27, 'Math 202', 2102, 'MATH 102', 8, 'Heb-201'),
(28, 'MATH 102', 2103, 'MATH 102', 11, 'Heb-201'),
(29, 'MATH 102', 2103, 'MATH 102', 10, 'Heb-201'),
(30, 'Class', 2102, 'CS 211', 9, 'Heb-201'),
(32, 'CS 121 - BSIT 2101', 2101, 'CS 121', 1, 'Heb-201'),
(34, 'CS 121 - BSIT 2102', 2102, 'CS 121', 1, 'Heb-201'),
(35, 'CS 121 - BSIT 2103', 2103, 'CS 121', 1, 'Heb-201'),
(36, 'CS 131 - BSIT 2101', 2101, 'CS 131', 1, 'Heb-202'),
(37, 'CS 131 - BSIT 2102', 2102, 'CS 131', 1, 'Heb-202'),
(38, 'CS 131 - BSIT 2103', 2103, 'CS 131', 1, 'Heb-202'),
(39, 'GEd 108 - BSIT 2101', 2101, 'GEd 108', 1, 'Heb-203'),
(40, 'GEd 108 - BSIT 2102', 2102, 'GEd 108', 1, 'Heb-203'),
(41, 'GEd 108 - BSIT 2103', 2103, 'GEd 108', 1, 'Heb-203'),
(42, 'GEd 103 - BSIT 2101', 2101, 'GEd 103', 1, 'Heb-204'),
(43, 'GEd 103 - BSIT 2102', 2102, 'GEd 103', 1, 'Heb-204'),
(44, 'GEd 103 - BSIT 2103', 2103, 'GEd 103', 1, 'Heb-204'),
(45, 'GEd 104 - BSIT 2101', 2101, 'GEd 104', 1, 'Heb-205'),
(46, 'GEd 104 - BSIT 2102', 2102, 'GEd 104', 1, 'Heb-205');

-- --------------------------------------------------------

--
-- Table structure for table `grades`
--

CREATE TABLE `grades` (
  `grades_id` int(11) NOT NULL,
  `activity1` double(5,2) DEFAULT NULL,
  `activity2` double(5,2) DEFAULT NULL,
  `activity3` double(5,2) DEFAULT NULL,
  `activity4` double(5,2) DEFAULT NULL,
  `activity5` double(5,2) DEFAULT NULL,
  `midterms` double(5,2) DEFAULT NULL,
  `finals` double(5,2) DEFAULT NULL,
  `project` double(5,2) DEFAULT NULL,
  `ave_grade` double(5,2) DEFAULT NULL,
  `student_id` int(11) NOT NULL,
  `automated_student_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `grades`
--

INSERT INTO `grades` (`grades_id`, `activity1`, `activity2`, `activity3`, `activity4`, `activity5`, `midterms`, `finals`, `project`, `ave_grade`, `student_id`, `automated_student_id`) VALUES
(2, 90.00, 80.00, 90.00, 90.00, 90.00, 100.00, 70.00, 65.00, 84.38, 49, NULL),
(3, 90.00, 90.00, 90.00, 90.00, 90.00, 90.00, 90.00, 90.00, 90.00, 50, NULL),
(4, 89.00, 90.00, 90.00, 80.00, 78.00, 90.00, 90.00, 100.00, 88.38, 51, NULL),
(5, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 52, NULL),
(6, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 53, NULL),
(7, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 54, NULL),
(8, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 55, NULL),
(9, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 56, NULL),
(10, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 57, NULL),
(11, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 58, NULL),
(12, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 59, NULL),
(13, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 60, NULL),
(14, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 63, NULL),
(15, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 64, NULL),
(16, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 65, NULL),
(17, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 66, NULL),
(18, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 67, NULL),
(19, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 68, NULL),
(20, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 69, NULL),
(21, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 70, NULL),
(22, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 71, NULL),
(23, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 72, NULL),
(24, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 73, NULL),
(25, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 74, NULL),
(26, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 75, NULL),
(27, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 76, NULL),
(28, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 77, NULL),
(29, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 78, NULL),
(30, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 79, NULL),
(31, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 80, NULL),
(32, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 81, NULL),
(33, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 82, NULL),
(34, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 83, NULL),
(35, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 84, NULL),
(36, 90.00, 88.00, 99.00, 84.00, 0.00, 0.00, 0.00, 0.00, 45.12, 85, NULL),
(37, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 86, NULL),
(38, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 87, NULL),
(39, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 88, NULL),
(40, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 89, NULL),
(41, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 90, NULL),
(42, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 91, NULL),
(43, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 92, NULL),
(44, 90.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 11.25, 93, NULL),
(45, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 94, NULL),
(46, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 95, NULL),
(47, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 96, NULL),
(48, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 97, NULL),
(49, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 98, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `room_id` int(11) NOT NULL,
  `room_name` varchar(50) NOT NULL,
  `capacity` int(11) DEFAULT NULL,
  `building` varchar(50) DEFAULT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`room_id`, `room_name`, `capacity`, `building`, `class_id`, `section_id`) VALUES
(1, 'Heb-201', 50, 'Higher Education Building', 0, 0),
(2, 'Heb-202', 50, 'Higher Education Building', 0, 0),
(3, 'Heb-203', 50, 'Higher Education Building', 0, 0),
(4, 'Heb-204', 50, 'Higher Education Building', 0, 0),
(5, 'Heb-205', 50, 'Higher Education Building', 0, 0),
(7, 'heb 206', 50, 'College of Teachers Education Building\r\n', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `schedules`
--

CREATE TABLE `schedules` (
  `schedule_id` int(11) NOT NULL,
  `class_id` int(11) DEFAULT NULL,
  `room_id` int(11) DEFAULT NULL,
  `day_of_week` enum('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday') DEFAULT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `class_name` varchar(255) DEFAULT NULL,
  `room_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `schedules`
--

INSERT INTO `schedules` (`schedule_id`, `class_id`, `room_id`, `day_of_week`, `start_time`, `end_time`, `class_name`, `room_name`) VALUES
(22, 34, 1, 'Monday', '10:00:00', '13:00:00', NULL, NULL),
(23, 35, 1, 'Monday', '13:30:00', '16:30:00', NULL, NULL),
(24, 36, 2, 'Monday', '11:00:00', '13:00:00', NULL, NULL),
(25, 37, 2, 'Monday', '07:00:00', '10:00:00', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sections`
--

CREATE TABLE `sections` (
  `section_id` int(11) NOT NULL,
  `section_name` varchar(255) DEFAULT NULL,
  `section_code` int(11) DEFAULT NULL,
  `student_count` int(11) DEFAULT NULL,
  `automated_student_id` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sections`
--

INSERT INTO `sections` (`section_id`, `section_name`, `section_code`, `student_count`, `automated_student_id`) VALUES
(4, 'BSIT', 2101, NULL, NULL),
(5, 'BSIT', 2102, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `student_id` int(11) NOT NULL,
  `student_firstname` varchar(255) NOT NULL,
  `student_lastname` varchar(255) NOT NULL,
  `section_code` varchar(255) DEFAULT NULL,
  `average_grade` int(11) DEFAULT NULL,
  `automated_student_id` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`student_id`, `student_firstname`, `student_lastname`, `section_code`, `average_grade`, `automated_student_id`) VALUES
(65, 'John Dave', 'Briones', '2102', 0, '24-00001'),
(66, 'Andre', 'Cachola', '2102', 0, '24-00002'),
(67, 'Aeron Marc', 'Salanguit', '2102', 0, '24-00003'),
(68, 'Jan Emmanuel', 'Formentos', '2102', 0, '24-00004'),
(69, 'Lee', 'Ricalde', '2102', 0, '24-00005'),
(70, 'Linux', 'Adona', '2101', 0, '24-00006'),
(71, 'John Eduard', 'De Villa', '2102', 0, '24-00007'),
(73, 'Niel Carlo', 'Delmo', '2102', 0, '24-00008'),
(74, 'Juan', 'De La Cruz', '2101', 0, '24-00009'),
(75, 'Juan', 'Enrile', '2101', 0, '24-00010'),
(76, 'Juan', 'Bautista', '2101', 0, '24-00011'),
(78, 'Melly', 'Cornado', '2102', 0, '24-00013'),
(79, 'Kristine', 'De Torres', '2102', 0, '24-00014'),
(80, 'Kaye', 'Macalalad', '2101', 0, '24-00015'),
(81, 'Rome', 'Salvid', '2101', 0, '24-00016'),
(82, 'Dyanne', 'Salas', '2101', 0, '24-00017'),
(83, 'Marc', 'Salanguit', '2101', 0, '24-00018'),
(84, 'Xyreel', 'Laguras', '2101', 0, '24-00019'),
(85, 'Jhezl', 'Baldos', '2101', 0, '24-00020'),
(86, 'Jhannine', 'Dela Rosa', '2101', 0, '24-00021');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `subject_id` int(11) NOT NULL,
  `subject_name` varchar(255) NOT NULL,
  `subject_code` varchar(255) NOT NULL,
  `subject_units` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`subject_id`, `subject_name`, `subject_code`, `subject_units`) VALUES
(13, 'Advanced Computer Programming', 'CS 121', 3),
(14, 'Data Structures and Algorithms', 'CS 131', 3),
(16, 'Art Appreciation', 'GEd 108', 3),
(17, 'The Life and Works of Rizal', 'GEd 103', 3),
(18, 'The Contemporary World', 'GEd 104', 3),
(19, 'Computer Programming', 'CS 111', 3);

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `teachers_id` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`teachers_id`, `fullname`, `password`, `email`) VALUES
(1, 'Joed Pogi', 'qwerty', 'joed123@gmail.com'),
(3, 'Joed D.', 'pogiako', 'joedD@gmail.com'),
(4, 'asd', 'asd', 'asd'),
(5, 'Xyreel Laguras', 'qwerty', 'laguras123@gmail.com'),
(6, 'Janine Gamez', 'zxcv', 'game'),
(7, 'jed1', '1', '1'),
(8, 'john eduard', '123456', 'joed@gmail.com'),
(9, 'juan', 'j', 'j'),
(10, 'kaye', 'k', 'k'),
(11, 'Linux', 'l', 'l');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `building`
--
ALTER TABLE `building`
  ADD PRIMARY KEY (`building_id`);

--
-- Indexes for table `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`class_id`),
  ADD KEY `teacher_id` (`teachers_id`),
  ADD KEY `fk_section_code` (`section_code`);

--
-- Indexes for table `grades`
--
ALTER TABLE `grades`
  ADD PRIMARY KEY (`grades_id`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`room_id`);

--
-- Indexes for table `schedules`
--
ALTER TABLE `schedules`
  ADD PRIMARY KEY (`schedule_id`),
  ADD UNIQUE KEY `room_id` (`room_id`,`day_of_week`,`start_time`,`end_time`),
  ADD KEY `class_id` (`class_id`);

--
-- Indexes for table `sections`
--
ALTER TABLE `sections`
  ADD PRIMARY KEY (`section_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`student_id`),
  ADD KEY `fk_section` (`section_code`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`subject_id`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`teachers_id`),
  ADD UNIQUE KEY `fullname` (`fullname`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `building`
--
ALTER TABLE `building`
  MODIFY `building_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `classes`
--
ALTER TABLE `classes`
  MODIFY `class_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `grades`
--
ALTER TABLE `grades`
  MODIFY `grades_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `room_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `schedules`
--
ALTER TABLE `schedules`
  MODIFY `schedule_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `sections`
--
ALTER TABLE `sections`
  MODIFY `section_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=99;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `subject_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
  MODIFY `teachers_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `classes`
--
ALTER TABLE `classes`
  ADD CONSTRAINT `classes_ibfk_1` FOREIGN KEY (`teachers_id`) REFERENCES `teachers` (`teachers_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
