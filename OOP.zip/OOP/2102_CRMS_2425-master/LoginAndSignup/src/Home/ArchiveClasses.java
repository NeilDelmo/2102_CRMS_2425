package Home;

import java.sql.DriverManager;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import javax.swing.table.DefaultTableModel;
import java.sql.Timestamp;

public final class ArchiveClasses extends javax.swing.JFrame {

    private static int currentTeachers_Id;

    // Static method to set the current teacher ID
    public static void setCurrentTeacherId(int teachers_id) {
        currentTeachers_Id = teachers_id;
    }

    public ArchiveClasses(int teachers_id) {
        currentTeachers_Id = teachers_id;
        initComponents();
        this.setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        loadArchiveClasses(); // This loads the archived classes
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel4 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btnRefresh_Students = new rojeru_san.complementos.RSButtonHover();
        jScrollPane1 = new javax.swing.JScrollPane();
        ArchiveClasses = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel4.setBackground(new java.awt.Color(0, 102, 102));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Classlogo.png"))); // NOI18N
        jLabel1.setText("Classroom");

        btnRefresh_Students.setBackground(new java.awt.Color(0, 102, 102));
        btnRefresh_Students.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/refresh.png"))); // NOI18N
        btnRefresh_Students.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnRefresh_StudentsMouseClicked(evt);
            }
        });
        btnRefresh_Students.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRefresh_StudentsActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(btnRefresh_Students, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnRefresh_Students, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        ArchiveClasses.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        ArchiveClasses.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ClassID", "Class Name", "Section", "Subject", "Time Deleted"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        ArchiveClasses.setRowHeight(25);
        ArchiveClasses.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(ArchiveClasses);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 940, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 429, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

   public void loadArchiveClasses() {
    System.out.println("Current Teacher ID: " + currentTeachers_Id);
    String url = "jdbc:mysql://localhost:3306/crms";
    String user = "root";
    String password = "";

    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;

    try {
        // Establish the database connection
        conn = DriverManager.getConnection(url, user, password);

        // SQL query to filter by teachers_id
        String query = "SELECT class_id, class_name, section_code, subject_code, time_deleted "
                       + "FROM archiveclasses WHERE teachers_id = ?";

        pstmt = conn.prepareStatement(query);
        pstmt.setInt(1, currentTeachers_Id); // Bind the current teacher's ID

        System.out.println("Executing query: " + pstmt.toString()); // Print the query for verification
        rs = pstmt.executeQuery();

        // Get the table model and clear previous data
        DefaultTableModel model = (DefaultTableModel) ArchiveClasses.getModel();
        model.setRowCount(0); // Clear previous data in the model

        // Check if the result set has data
        if (!rs.isBeforeFirst()) {
            JOptionPane.showMessageDialog(this, "No archived classes found for teacher ID: " + currentTeachers_Id, "No Data", JOptionPane.INFORMATION_MESSAGE);
            return; // No data found
        }

        // Populate the table model with data
        while (rs.next()) {
            Integer classId = rs.getInt("class_id");
            String className = rs.getString("class_name");
            String sectionCode = rs.getString("section_code");
            String subject = rs.getString("subject_code");
            Timestamp timeDeleted = rs.getTimestamp("time_deleted");

            // Create a row data array
            Object[] rowData = {
                classId,
                className,
                sectionCode,
                subject,
                timeDeleted // Display the time the class was deleted
            };

            model.addRow(rowData); // Add to model
        }

        // Optionally, auto-resize columns
        ArchiveClasses.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this,
                                      "Database error: " + e.getMessage(),
                                      "Error",
                                      JOptionPane.ERROR_MESSAGE);
     }
   }

    private Teach homeFrame; // Add a reference to the Teach frame
    private void btnSubjects_HomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSubjects_HomeActionPerformed

    }//GEN-LAST:event_btnSubjects_HomeActionPerformed

    private void btnRefresh_StudentsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnRefresh_StudentsMouseClicked

    }//GEN-LAST:event_btnRefresh_StudentsMouseClicked

    private void btnRefresh_StudentsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRefresh_StudentsActionPerformed
        loadArchiveClasses();
    }//GEN-LAST:event_btnRefresh_StudentsActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable ArchiveClasses;
    private rojeru_san.complementos.RSButtonHover btnRefresh_Students;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
