package Home;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import loginandsignup.Login;
import java.sql.Statement;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.*;
import java.sql.*;

public class Rooms extends javax.swing.JFrame {
    String URL = "jdbc:mysql://localhost:3306/crms"; 
    String USER = "root"; 
    String PASS = ""; 
    
    public Rooms() {
        initComponents();
         this.setExtendedState(Rooms.MAXIMIZED_BOTH);
         LoadRooms();
    }
    
private void LoadRooms() {
    
    DefaultTableModel model = (DefaultTableModel) Rooms_Table.getModel(); 
    model.setRowCount(0); // Clear existing rows

    // Updated query to count students in each section
    
String query = "SELECT room_id, room_name, capacity, building FROM rooms";
try (Connection con = DriverManager.getConnection(URL, USER, PASS);
         Statement stmt = con.createStatement();
         ResultSet rs = stmt.executeQuery(query)) {

        while (rs.next()) {
            int roomId = rs.getInt("room_id");
            String roomName = rs.getString("room_name");
            int capacity = rs.getInt("capacity");
            String building =rs.getString("building");

            // Add the retrieved row to the table model
            model.addRow(new Object[]{roomId, roomName, capacity, building});
        }

    } catch (SQLException e) {
        e.printStackTrace(); // Print the stack trace for debugging
        JOptionPane.showMessageDialog(this, "Error loading Sections: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}

// Method to count the number of students in a specific section
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel4 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btnAddRooms_Rooms = new rojeru_san.complementos.RSButtonHover();
        btnRemoveRoom_Rooms = new rojeru_san.complementos.RSButtonHover();
        btnRefresh_Rooms = new rojeru_san.complementos.RSButtonHover();
        jPanel1 = new javax.swing.JPanel();
        btnHome_Rooms = new rojeru_san.complementos.RSButtonHover();
        btnTeach_Rooms = new rojeru_san.complementos.RSButtonHover();
        btnLogout_Subjects = new rojeru_san.complementos.RSButtonHover();
        btnStudents_Rooms = new rojeru_san.complementos.RSButtonHover();
        btnSections_Rooms = new rojeru_san.complementos.RSButtonHover();
        btnRooms_Rooms = new rojeru_san.complementos.RSButtonHover();
        btnGrades_Rooms = new rojeru_san.complementos.RSButtonHover();
        btnSubjects__Rooms = new rojeru_san.complementos.RSButtonHover();
        jScrollPane1 = new javax.swing.JScrollPane();
        Rooms_Table = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel4.setBackground(new java.awt.Color(0, 102, 102));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Classlogo.png"))); // NOI18N
        jLabel1.setText("Rooms");

        btnAddRooms_Rooms.setBackground(new java.awt.Color(0, 102, 102));
        btnAddRooms_Rooms.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/plus.png"))); // NOI18N
        btnAddRooms_Rooms.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddRooms_RoomsActionPerformed(evt);
            }
        });

        btnRemoveRoom_Rooms.setBackground(new java.awt.Color(0, 102, 102));
        btnRemoveRoom_Rooms.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/minus.png"))); // NOI18N
        btnRemoveRoom_Rooms.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoveRoom_RoomsActionPerformed(evt);
            }
        });

        btnRefresh_Rooms.setBackground(new java.awt.Color(0, 102, 102));
        btnRefresh_Rooms.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/refresh.png"))); // NOI18N
        btnRefresh_Rooms.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRefresh_RoomsActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(btnRefresh_Rooms, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnRemoveRoom_Rooms, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnAddRooms_Rooms, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(13, 13, 13))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnRefresh_Rooms, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnRemoveRoom_Rooms, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAddRooms_Rooms, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(16, 16, 16))
        );

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        btnHome_Rooms.setBackground(new java.awt.Color(255, 255, 255));
        btnHome_Rooms.setForeground(new java.awt.Color(0, 0, 0));
        btnHome_Rooms.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Home.png"))); // NOI18N
        btnHome_Rooms.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHome_RoomsActionPerformed(evt);
            }
        });

        btnTeach_Rooms.setBackground(new java.awt.Color(255, 255, 255));
        btnTeach_Rooms.setForeground(new java.awt.Color(0, 0, 0));
        btnTeach_Rooms.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Teach.png"))); // NOI18N
        btnTeach_Rooms.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTeach_RoomsActionPerformed(evt);
            }
        });

        btnLogout_Subjects.setBackground(new java.awt.Color(255, 255, 255));
        btnLogout_Subjects.setForeground(new java.awt.Color(0, 0, 0));
        btnLogout_Subjects.setText("Logout");
        btnLogout_Subjects.setColorHover(new java.awt.Color(204, 204, 204));
        btnLogout_Subjects.setColorText(new java.awt.Color(0, 0, 0));
        btnLogout_Subjects.setColorTextHover(new java.awt.Color(0, 0, 0));
        btnLogout_Subjects.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnLogout_Subjects.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogout_SubjectsActionPerformed(evt);
            }
        });

        btnStudents_Rooms.setBackground(new java.awt.Color(255, 255, 255));
        btnStudents_Rooms.setForeground(new java.awt.Color(0, 0, 0));
        btnStudents_Rooms.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Students.png"))); // NOI18N
        btnStudents_Rooms.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStudents_RoomsActionPerformed(evt);
            }
        });

        btnSections_Rooms.setBackground(new java.awt.Color(255, 255, 255));
        btnSections_Rooms.setForeground(new java.awt.Color(0, 0, 0));
        btnSections_Rooms.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/section.png"))); // NOI18N
        btnSections_Rooms.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSections_RoomsActionPerformed(evt);
            }
        });

        btnRooms_Rooms.setBackground(new java.awt.Color(255, 255, 255));
        btnRooms_Rooms.setForeground(new java.awt.Color(0, 0, 0));
        btnRooms_Rooms.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/classroom.png"))); // NOI18N
        btnRooms_Rooms.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRooms_RoomsActionPerformed(evt);
            }
        });

        btnGrades_Rooms.setBackground(new java.awt.Color(255, 255, 255));
        btnGrades_Rooms.setForeground(new java.awt.Color(0, 0, 0));
        btnGrades_Rooms.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/grades.png"))); // NOI18N
        btnGrades_Rooms.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGrades_RoomsActionPerformed(evt);
            }
        });

        btnSubjects__Rooms.setBackground(new java.awt.Color(255, 255, 255));
        btnSubjects__Rooms.setForeground(new java.awt.Color(0, 0, 0));
        btnSubjects__Rooms.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Subjects.png"))); // NOI18N
        btnSubjects__Rooms.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSubjects__RoomsActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnTeach_Rooms, javax.swing.GroupLayout.DEFAULT_SIZE, 86, Short.MAX_VALUE)
                    .addComponent(btnHome_Rooms, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(btnLogout_Subjects, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(btnStudents_Rooms, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(btnSections_Rooms, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(btnRooms_Rooms, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(btnGrades_Rooms, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(btnSubjects__Rooms, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(64, 64, 64)
                .addComponent(btnHome_Rooms, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnTeach_Rooms, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnGrades_Rooms, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnStudents_Rooms, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnSections_Rooms, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnRooms_Rooms, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnSubjects__Rooms, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 13, Short.MAX_VALUE)
                .addComponent(btnLogout_Subjects, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        Rooms_Table.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        Rooms_Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Room_Number", "Room_Name", "Capacity", "Building"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        Rooms_Table.setRowHeight(25);
        jScrollPane1.setViewportView(Rooms_Table);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 720, Short.MAX_VALUE)
                .addContainerGap())
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 47, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(67, 67, 67)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnHome_RoomsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHome_RoomsActionPerformed
         Home homeFrame = new Home();
        homeFrame.setExtendedState(Home.MAXIMIZED_BOTH); // Set full screen
        homeFrame.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnHome_RoomsActionPerformed

    private void btnTeach_RoomsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTeach_RoomsActionPerformed
    Teach teachFrame = new Teach();
    teachFrame.setExtendedState(Teach.MAXIMIZED_BOTH); // Set full screen
    teachFrame.setVisible(true);
    this.dispose();
    }//GEN-LAST:event_btnTeach_RoomsActionPerformed

    private void btnAddRooms_RoomsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddRooms_RoomsActionPerformed
        // TODO add your handling code here:
         AddRoom addroomsFrame = new AddRoom();
         addroomsFrame.setVisible(true);
    }//GEN-LAST:event_btnAddRooms_RoomsActionPerformed

    private void btnLogout_SubjectsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogout_SubjectsActionPerformed
        // TODO add your handling code here:                                    
             int response = JOptionPane.showConfirmDialog(
                       this, 
                       "Do you really want to log out?", 
                       "Confirm Logout", 
                        JOptionPane.YES_NO_OPTION, 
                        JOptionPane.QUESTION_MESSAGE
             );
    
              if (response == JOptionPane.YES_OPTION) {
                    // User chose to log out
                        Login l = new Login();
                        l.setVisible(true);
                        this.dispose();
               } else {

    }

    }//GEN-LAST:event_btnLogout_SubjectsActionPerformed

    private void btnStudents_RoomsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStudents_RoomsActionPerformed
        Students studentsFrame = new Students();
         studentsFrame.setExtendedState(Students.MAXIMIZED_BOTH); // Set full screen
         studentsFrame.setVisible(true);
         this.dispose();
    }//GEN-LAST:event_btnStudents_RoomsActionPerformed

    private void btnSections_RoomsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSections_RoomsActionPerformed
         Sections sectionsFrame = new Sections(Home.currentTeachers_Id);
         sectionsFrame.setExtendedState(Sections.MAXIMIZED_BOTH);
         sectionsFrame.setVisible(true);
    }//GEN-LAST:event_btnSections_RoomsActionPerformed

    private void btnRemoveRoom_RoomsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRemoveRoom_RoomsActionPerformed
      int selectedRow = Rooms_Table.getSelectedRow(); // Get selected row index
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Please select a room to delete.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int selectedRoomId = (int) Rooms_Table.getValueAt(selectedRow, 0); // Get room ID from the selected row

        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete the selected room with ID: " + selectedRoomId + "?",
                "Confirm Delete", JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            deleteRoom(selectedRoomId);
        }
    }

    private void deleteRoom(int roomId) {
        String deleteSQL = "DELETE FROM rooms WHERE room_id = ?"; // Adjust according to your database schema

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement(deleteSQL)) {
            
            pstmt.setInt(1, roomId);
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Room deleted successfully!");
                LoadRooms(); // Refresh the list of rooms after deletion
            } else {
                JOptionPane.showMessageDialog(this, "Failed to delete room.", "Database Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error deleting room: " + ex.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnRemoveRoom_RoomsActionPerformed

    private void btnRooms_RoomsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRooms_RoomsActionPerformed
        // TODO add your handling code here:
         JOptionPane.showMessageDialog(new JFrame(), "You are already in the Rooms window.", "Error", JOptionPane.ERROR_MESSAGE);
    }//GEN-LAST:event_btnRooms_RoomsActionPerformed

    private void btnGrades_RoomsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGrades_RoomsActionPerformed

    }//GEN-LAST:event_btnGrades_RoomsActionPerformed

    private void btnRefresh_RoomsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRefresh_RoomsActionPerformed
        // TODO add your handling code here:
        LoadRooms();
    }//GEN-LAST:event_btnRefresh_RoomsActionPerformed

    private void btnSubjects__RoomsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSubjects__RoomsActionPerformed
        // TODO add your handling code here:
        Subjects subjectsFrame = new Subjects ();
        subjectsFrame.setExtendedState(Subjects.MAXIMIZED_BOTH);
        subjectsFrame.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnSubjects__RoomsActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        SwingUtilities.invokeLater(() -> new AddRoom().setVisible(true));
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Rooms.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Rooms.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Rooms.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Rooms.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
     
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Rooms().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable Rooms_Table;
    private rojeru_san.complementos.RSButtonHover btnAddRooms_Rooms;
    private rojeru_san.complementos.RSButtonHover btnGrades_Rooms;
    private rojeru_san.complementos.RSButtonHover btnHome_Rooms;
    private rojeru_san.complementos.RSButtonHover btnLogout_Subjects;
    private rojeru_san.complementos.RSButtonHover btnRefresh_Rooms;
    private rojeru_san.complementos.RSButtonHover btnRemoveRoom_Rooms;
    private rojeru_san.complementos.RSButtonHover btnRooms_Rooms;
    private rojeru_san.complementos.RSButtonHover btnSections_Rooms;
    private rojeru_san.complementos.RSButtonHover btnStudents_Rooms;
    private rojeru_san.complementos.RSButtonHover btnSubjects__Rooms;
    private rojeru_san.complementos.RSButtonHover btnTeach_Rooms;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables

}
