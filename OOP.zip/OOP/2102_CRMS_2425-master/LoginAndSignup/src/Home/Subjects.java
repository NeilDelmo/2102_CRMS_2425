package Home;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import loginandsignup.Login;

public class Subjects extends javax.swing.JFrame {
    String URL = "jdbc:mysql://localhost:3306/crms";
    String USER = "root";
    String PASS = "";
        
    // Constructor that accepts the teacher's ID
    public Subjects() {
        initComponents();  // Initialize UI components
        this.setExtendedState(Subjects.MAXIMIZED_BOTH);
        LoadSubjects();
    }
void LoadSubjects() {
        
        DefaultTableModel model = (DefaultTableModel) SubjectsTable.getModel();
        model.setRowCount(0);

        // Corrected SQL query
        String query = "SELECT subject_id, subject_name, subject_code, subject_units FROM subjects ";
   
        try (Connection con = DriverManager.getConnection(URL, USER, PASS)) {
            PreparedStatement stmt = con.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("subject_id");
                String subjectName = rs.getString("subject_name");
                String subjectCode = rs.getString("subject_code");  // NULL-safe if sections.section_id doesn't match
                int subjectUnit = rs.getInt("subject_units");

                model.addRow(new Object[]{id, subjectName, subjectCode, subjectUnit});
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading students: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel4 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btnAddClass_Subjects = new rojeru_san.complementos.RSButtonHover();
        btnRemoveSubjects_Subjects = new rojeru_san.complementos.RSButtonHover();
        btnRefresh_Students = new rojeru_san.complementos.RSButtonHover();
        jScrollPane1 = new javax.swing.JScrollPane();
        SubjectsTable = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        btnHome_Subjects = new rojeru_san.complementos.RSButtonHover();
        btnTeach_Subjects = new rojeru_san.complementos.RSButtonHover();
        btnLogout_Home = new rojeru_san.complementos.RSButtonHover();
        btnStudents_Subjects = new rojeru_san.complementos.RSButtonHover();
        btnRooms_Subjects = new rojeru_san.complementos.RSButtonHover();
        btnGrades_Subjects = new rojeru_san.complementos.RSButtonHover();
        btnSections_Subjects = new rojeru_san.complementos.RSButtonHover();
        btnSubjects__Subjects = new rojeru_san.complementos.RSButtonHover();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel4.setBackground(new java.awt.Color(0, 102, 102));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Classlogo.png"))); // NOI18N
        jLabel1.setText("Subjects");

        btnAddClass_Subjects.setBackground(new java.awt.Color(0, 102, 102));
        btnAddClass_Subjects.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/plus.png"))); // NOI18N
        btnAddClass_Subjects.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddClass_SubjectsActionPerformed(evt);
            }
        });

        btnRemoveSubjects_Subjects.setBackground(new java.awt.Color(0, 102, 102));
        btnRemoveSubjects_Subjects.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/minus.png"))); // NOI18N
        btnRemoveSubjects_Subjects.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoveSubjects_SubjectsActionPerformed(evt);
            }
        });

        btnRefresh_Students.setBackground(new java.awt.Color(0, 102, 102));
        btnRefresh_Students.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/refresh.png"))); // NOI18N
        btnRefresh_Students.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRefresh_StudentsActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(btnRefresh_Students, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnRemoveSubjects_Subjects, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnAddClass_Subjects, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 19, 19))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnRefresh_Students, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnRemoveSubjects_Subjects, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAddClass_Subjects, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(16, 16, 16))
        );

        SubjectsTable.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        SubjectsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Subject_Id", "Subject_Name", "Subject_Code", "Units"
            }
        ));
        SubjectsTable.setRowHeight(25);
        jScrollPane1.setViewportView(SubjectsTable);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        btnHome_Subjects.setBackground(new java.awt.Color(255, 255, 255));
        btnHome_Subjects.setForeground(new java.awt.Color(0, 0, 0));
        btnHome_Subjects.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Home.png"))); // NOI18N
        btnHome_Subjects.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHome_SubjectsActionPerformed(evt);
            }
        });

        btnTeach_Subjects.setBackground(new java.awt.Color(255, 255, 255));
        btnTeach_Subjects.setForeground(new java.awt.Color(0, 0, 0));
        btnTeach_Subjects.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Teach.png"))); // NOI18N
        btnTeach_Subjects.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTeach_SubjectsActionPerformed(evt);
            }
        });

        btnLogout_Home.setBackground(new java.awt.Color(255, 255, 255));
        btnLogout_Home.setForeground(new java.awt.Color(0, 0, 0));
        btnLogout_Home.setText("Logout");
        btnLogout_Home.setColorHover(new java.awt.Color(204, 204, 204));
        btnLogout_Home.setColorText(new java.awt.Color(0, 0, 0));
        btnLogout_Home.setColorTextHover(new java.awt.Color(0, 0, 0));
        btnLogout_Home.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnLogout_Home.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogout_HomeActionPerformed(evt);
            }
        });

        btnStudents_Subjects.setBackground(new java.awt.Color(255, 255, 255));
        btnStudents_Subjects.setForeground(new java.awt.Color(0, 0, 0));
        btnStudents_Subjects.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Students.png"))); // NOI18N
        btnStudents_Subjects.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStudents_SubjectsActionPerformed(evt);
            }
        });

        btnRooms_Subjects.setBackground(new java.awt.Color(255, 255, 255));
        btnRooms_Subjects.setForeground(new java.awt.Color(0, 0, 0));
        btnRooms_Subjects.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/classroom.png"))); // NOI18N
        btnRooms_Subjects.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRooms_SubjectsActionPerformed(evt);
            }
        });

        btnGrades_Subjects.setBackground(new java.awt.Color(255, 255, 255));
        btnGrades_Subjects.setForeground(new java.awt.Color(0, 0, 0));
        btnGrades_Subjects.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/grades.png"))); // NOI18N
        btnGrades_Subjects.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGrades_SubjectsActionPerformed(evt);
            }
        });

        btnSections_Subjects.setBackground(new java.awt.Color(255, 255, 255));
        btnSections_Subjects.setForeground(new java.awt.Color(0, 0, 0));
        btnSections_Subjects.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/section.png"))); // NOI18N
        btnSections_Subjects.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSections_SubjectsActionPerformed(evt);
            }
        });

        btnSubjects__Subjects.setBackground(new java.awt.Color(255, 255, 255));
        btnSubjects__Subjects.setForeground(new java.awt.Color(0, 0, 0));
        btnSubjects__Subjects.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Subjects.png"))); // NOI18N
        btnSubjects__Subjects.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSubjects__SubjectsActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnTeach_Subjects, javax.swing.GroupLayout.DEFAULT_SIZE, 86, Short.MAX_VALUE)
                    .addComponent(btnHome_Subjects, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(btnLogout_Home, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(btnStudents_Subjects, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(btnGrades_Subjects, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(btnSections_Subjects, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(btnRooms_Subjects, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(btnSubjects__Subjects, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(64, 64, 64)
                .addComponent(btnHome_Subjects, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnTeach_Subjects, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnGrades_Subjects, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnStudents_Subjects, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnSections_Subjects, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnRooms_Subjects, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnSubjects__Subjects, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 42, Short.MAX_VALUE)
                .addComponent(btnLogout_Home, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 714, Short.MAX_VALUE)
                .addGap(12, 12, 12))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 500, Short.MAX_VALUE)
                        .addContainerGap())))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnHome_SubjectsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHome_SubjectsActionPerformed
        Home HomeFrame = new Home();
        HomeFrame.setExtendedState(Home.MAXIMIZED_BOTH);
        HomeFrame.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnHome_SubjectsActionPerformed

    private void btnTeach_SubjectsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTeach_SubjectsActionPerformed

    }//GEN-LAST:event_btnTeach_SubjectsActionPerformed

    private void btnLogout_HomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogout_HomeActionPerformed
        // TODO add your handling code here:
        int response = JOptionPane.showConfirmDialog(
            this,
            "Do you really want to log out?",
            "Confirm Logout",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE
        );

        if (response == JOptionPane.YES_OPTION) {
            // User chose to log out
            Login l = new Login();
            l.setVisible(true);
            this.dispose();
        } else {

        }
    }//GEN-LAST:event_btnLogout_HomeActionPerformed

    private void btnStudents_SubjectsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStudents_SubjectsActionPerformed
        Students studentsFrame = new Students();
        studentsFrame.setExtendedState(Students.MAXIMIZED_BOTH); // Set full screen
        studentsFrame.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnStudents_SubjectsActionPerformed

    private void btnRooms_SubjectsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRooms_SubjectsActionPerformed
        // TODO add your handling code here:
        Rooms roomsFrame = new Rooms();
        roomsFrame.setExtendedState(Rooms.MAXIMIZED_BOTH);
        roomsFrame.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnRooms_SubjectsActionPerformed

    private void btnGrades_SubjectsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGrades_SubjectsActionPerformed
        // TODO add your handling code here:
        // Pass the current teacher ID when creating the Grades instance
    Grades gradesFrame = new Grades(Home.currentTeachers_Id);
    gradesFrame.setExtendedState(Grades.MAXIMIZED_BOTH); // Set full screen
    gradesFrame.setVisible(true);
    this.dispose(); // Dispose current frame if that's the intended behavior
    }//GEN-LAST:event_btnGrades_SubjectsActionPerformed

    private void btnSections_SubjectsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSections_SubjectsActionPerformed
        // TODO add your handling code here:
        Sections sectionsFrame = new Sections(Home.currentTeachers_Id);
        sectionsFrame.setExtendedState(Sections.MAXIMIZED_BOTH);
        sectionsFrame.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnSections_SubjectsActionPerformed

    private void btnSubjects__SubjectsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSubjects__SubjectsActionPerformed
       JOptionPane.showMessageDialog(new JFrame(), "You are already in the subjects window.", "Error", JOptionPane.ERROR_MESSAGE);
    }//GEN-LAST:event_btnSubjects__SubjectsActionPerformed

    private void btnAddClass_SubjectsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddClass_SubjectsActionPerformed
        // TODO add your handling code here:
        AddSubjects addsubjectsFrame = new AddSubjects();
        addsubjectsFrame.setVisible(true);
    }//GEN-LAST:event_btnAddClass_SubjectsActionPerformed

    private void btnRemoveSubjects_SubjectsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRemoveSubjects_SubjectsActionPerformed
             int selectedRow = SubjectsTable.getSelectedRow(); // Get selected row index
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Please select a subject to delete.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int subjectId = (int) SubjectsTable.getValueAt(selectedRow, 0); // Assuming ID is the first column

        // Confirm deletion
        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete student with ID: " + subjectId + "?",
                "Confirm Deletion",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE);

        if (confirm == JOptionPane.YES_OPTION) {
            deleteSubject(subjectId); // Call method to delete student
        }
    }

    private void deleteSubject(int subjectId) {
        String deleteSQL = "DELETE FROM subjects WHERE subject_id = ?"; // Assuming 'student_id' is the primary key

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS); PreparedStatement pstmt = conn.prepareStatement(deleteSQL)) {

            pstmt.setInt(1, subjectId); // Set student ID in the prepared statement
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "subject deleted successfully!");
            } else {
                JOptionPane.showMessageDialog(this, "Failed to delete subject. Please try again.", "Database Error", JOptionPane.ERROR_MESSAGE);
            }

            LoadSubjects(); // Refresh the students table after deletion
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error deleting subject: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnRemoveSubjects_SubjectsActionPerformed

    private void btnRefresh_StudentsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRefresh_StudentsActionPerformed
        // TODO add your handling code here:
        LoadSubjects();
    }//GEN-LAST:event_btnRefresh_StudentsActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Subjects.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Subjects.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Subjects.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Subjects.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
       
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                 new Subjects().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable SubjectsTable;
    private rojeru_san.complementos.RSButtonHover btnAddClass_Subjects;
    private rojeru_san.complementos.RSButtonHover btnGrades_Subjects;
    private rojeru_san.complementos.RSButtonHover btnHome_Subjects;
    private rojeru_san.complementos.RSButtonHover btnLogout_Home;
    private rojeru_san.complementos.RSButtonHover btnRefresh_Students;
    private rojeru_san.complementos.RSButtonHover btnRemoveSubjects_Subjects;
    private rojeru_san.complementos.RSButtonHover btnRooms_Subjects;
    private rojeru_san.complementos.RSButtonHover btnSections_Subjects;
    private rojeru_san.complementos.RSButtonHover btnStudents_Subjects;
    private rojeru_san.complementos.RSButtonHover btnSubjects__Subjects;
    private rojeru_san.complementos.RSButtonHover btnTeach_Subjects;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables

}
