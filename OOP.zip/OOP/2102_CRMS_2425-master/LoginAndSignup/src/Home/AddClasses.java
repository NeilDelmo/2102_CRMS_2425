package Home;

import java.awt.Color;
import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author L E N O V O
 */
public class AddClasses extends javax.swing.JFrame {

    private Home homeFrame;
    private int loggedInteachers_id; // Store the ID of the logged-in teacher

    // Add setter/getter
    public void setLoggedInTeacherId(int teachers_Id) {
        this.loggedInteachers_id = teachers_Id;
    }

    public int getLoggedInTeacherId() {
        return this.loggedInteachers_id;
    }

    private static final String URL = "jdbc:mysql://localhost:3306/crms"; // Change to your database name
    private static final String USER = "root"; // Change to your MySQL username
    private static final String PASS = ""; // Change to your MySQL password

    private Map<String, Integer> sectionIdMap; // To store section_code -> section_id mapping
    private Map<String, Integer> subjectIdMap;
    private Map<String, Integer> roomsIdMap;

    public AddClasses(Home homeFrame, int teacherId) {
        this.homeFrame = homeFrame;
        this.loggedInteachers_id = teacherId;
        sectionIdMap = new HashMap<>(); // Initialize the map
        subjectIdMap = new HashMap<>();
        roomsIdMap = new HashMap<>();
        initComponents();
        loadSections(); // Load sections after components are initialized
        loadSubjects();
        loadRooms();
        setButtonStyles();
        setupKeyNavigation();
        this.setLocationRelativeTo(null);
        getRootPane().setDefaultButton(CreateButton);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }

    public AddClasses() {
        initComponents();
        loadSections(); // Load sections after components are initialized
        loadSubjects();
        loadRooms();
        setButtonStyles();
        setupKeyNavigation(); // Call to set up key navigation
        this.setLocationRelativeTo(null);

        // Set default button
        getRootPane().setDefaultButton(CreateButton);
    }

    private void setupKeyNavigation() {

        // Global key listener for ESC to close the window
        addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ESCAPE) {
                    dispose();
                }
            }
        });
    }

    private void loadSections() {
        String query = "SELECT section_id, section_name, section_code FROM sections";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASS); PreparedStatement pstmt = conn.prepareStatement(query)) {

            ResultSet rs = pstmt.executeQuery();
            sectionsComboBox.removeAllItems(); // Clear existing items
            sectionsComboBox.addItem("Select Section"); // Add default option

            while (rs.next()) {
                String sectionCode = rs.getString("section_code");
                int sectionId = rs.getInt("section_id");
                sectionIdMap.put(sectionCode, sectionId);
                sectionsComboBox.addItem(sectionCode);
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading sections: " + ex.getMessage());
        }
    }

    private void loadSubjects() {
        String query = "SELECT subject_id, subject_code FROM subjects";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASS); PreparedStatement pstmt = conn.prepareStatement(query)) {

            ResultSet rs = pstmt.executeQuery();
            subjectsComboBox.removeAllItems(); // Clear existing items
            subjectsComboBox.addItem("Select Subject"); // Add default option

            while (rs.next()) {
                String subjectCode = rs.getString("subject_code");
                int subjectId = rs.getInt("subject_id");
                subjectIdMap.put(subjectCode, subjectId);
                subjectsComboBox.addItem(subjectCode);
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading subjects: " + ex.getMessage());
        }
    }

    private void loadRooms() {
        String query = "SELECT room_id, room_name FROM rooms";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASS); PreparedStatement pstmt = conn.prepareStatement(query)) {

            ResultSet rs = pstmt.executeQuery();
            roomsComboBox.removeAllItems(); // Clear existing items
            roomsComboBox.addItem("Select room"); // Add default option

            while (rs.next()) {
                String roomName = rs.getString("room_name");
                int roomId = rs.getInt("room_id");
                roomsIdMap.put(roomName, roomId);
                roomsComboBox.addItem(roomName);
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading rooms: " + ex.getMessage());
        }
    }

    private boolean isClassAlreadyExists(String className, String sectionCode) {
        String query = "SELECT COUNT(*) FROM classes WHERE class_name = ? AND section_code = ? AND teachers_id = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASS); PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, className);
            pstmt.setString(2, sectionCode);
            pstmt.setInt(3, this.loggedInteachers_id); // Check by the logged-in teacher's ID

            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0; // Return true if count is greater than 0
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return false; // Default to false if no match is found or error occurs
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        ClassName = new app.bolivia.swing.JCTextField();
        CreateButton = new javax.swing.JButton();
        CancelButton = new javax.swing.JButton();
        sectionsComboBox = new javax.swing.JComboBox<>();
        subjectsComboBox = new javax.swing.JComboBox<>();
        roomsComboBox = new javax.swing.JComboBox<>();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setMinimumSize(new java.awt.Dimension(500, 600));

        ClassName.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Class Name", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Segoe UI", 2, 14))); // NOI18N
        ClassName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClassNameActionPerformed(evt);
            }
        });

        CreateButton.setText("Add");
        CreateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CreateButtonActionPerformed(evt);
            }
        });

        CancelButton.setText("Cancel");
        CancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelButtonActionPerformed(evt);
            }
        });

        sectionsComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sectionsComboBoxActionPerformed(evt);
            }
        });

        subjectsComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                subjectsComboBoxActionPerformed(evt);
            }
        });

        roomsComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                roomsComboBoxActionPerformed(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(0, 102, 102));

        jLabel1.setBackground(new java.awt.Color(0, 102, 102));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Classlogo.png"))); // NOI18N
        jLabel1.setText("Add Class");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel1)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(ClassName, javax.swing.GroupLayout.PREFERRED_SIZE, 467, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(roomsComboBox, javax.swing.GroupLayout.Alignment.LEADING, 0, 150, Short.MAX_VALUE)
                            .addComponent(subjectsComboBox, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(sectionsComboBox, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(162, 162, 162)
                        .addComponent(CancelButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(CreateButton)))
                .addContainerGap(10, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(ClassName, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(sectionsComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CancelButton)
                    .addComponent(CreateButton))
                .addGap(18, 18, 18)
                .addComponent(subjectsComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(roomsComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 363, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    private void setButtonStyles() {
        // Create button style
        CreateButton.setBackground(new Color(255, 255, 255, 0)); // Transparent background
        CreateButton.setForeground(Color.BLACK); // Black text
        CreateButton.setBorder(BorderFactory.createEmptyBorder()); // No border
        CreateButton.setFocusPainted(false); // Remove focus outline
        CreateButton.setFont(new Font("Segoe UI", Font.PLAIN, 14)); // Regular font
        CreateButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); // Hand cursor on hover

        // Cancel button style
        CancelButton.setBackground(new Color(255, 255, 255, 0)); // Transparent background
        CancelButton.setForeground(Color.BLACK); // Black text
        CancelButton.setBorder(BorderFactory.createEmptyBorder()); // No border
        CancelButton.setFocusPainted(false); // Remove focus outline
        CancelButton.setFont(new Font("Segoe UI", Font.PLAIN, 14)); // Regular font
        CancelButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); // Hand cursor on hover

        // Add mouse listeners for hover effects
        CreateButton.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                CreateButton.setForeground(new Color(0, 120, 60)); // Change text color on hover
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                CreateButton.setForeground(Color.BLACK); // Original text color
            }
        });

        CancelButton.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                CancelButton.setForeground(new Color(200, 0, 0)); // Change text color on hover
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                CancelButton.setForeground(Color.BLACK); // Original text color
            }
        });
    }
    private void ClassNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClassNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ClassNameActionPerformed

    private void CancelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelButtonActionPerformed
        this.dispose();
    }//GEN-LAST:event_CancelButtonActionPerformed

    private void CreateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CreateButtonActionPerformed

        String className = ClassName.getText().trim();
        String sectionCode = (String) sectionsComboBox.getSelectedItem();
        String subjectCode = (String) subjectsComboBox.getSelectedItem();
        String roomName = (String) roomsComboBox.getSelectedItem();

        // Check if all fields are filled
        if (className.equals("")) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields and select a section and subject.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (sectionCode.equals("Select Section")) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields and select a section and subject.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (subjectCode.equals("Select Subject")) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields and select a section and subject.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (roomName.equals("Select Room")) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields and select a section and subject.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Check if the class already exists in the same section for the current teacher
        if (isClassAlreadyExists(className, sectionCode)) {
            JOptionPane.showMessageDialog(this, "This class already exists in the selected section.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Get section ID from map for further validation if necessary
        Integer sectionId = sectionIdMap.get(sectionCode);
        if (sectionId == null) {
            JOptionPane.showMessageDialog(this, "Invalid section selected.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // SQL command to insert a new class into the database
        String insertSQL = "INSERT INTO classes(class_name, section_code, subject_code, room_name, teachers_id) VALUES(?, ?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASS); PreparedStatement pstmt = conn.prepareStatement(insertSQL)) {

            // Set parameters for the SQL query
            pstmt.setString(1, className);
            pstmt.setString(2, sectionCode);
            pstmt.setString(3, subjectCode);
            pstmt.setString(4, roomName);
            pstmt.setInt(5, this.loggedInteachers_id); // Use the teacher ID

            // Execute the update and check if successful
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Class added successfully!");

                // Refresh classes in the Home frame
                if (homeFrame != null) {
                    homeFrame.loadClasses();
                }

                // Clear the fields after successful addition
                ClassName.setText("");
                sectionsComboBox.setSelectedIndex(0);
                subjectsComboBox.setSelectedIndex(0);
                roomsComboBox.setSelectedIndex(0);
            } else {
                JOptionPane.showMessageDialog(this, "Failed to add class.", "Database Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error adding class: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_CreateButtonActionPerformed

    private void subjectsComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_subjectsComboBoxActionPerformed

    }//GEN-LAST:event_subjectsComboBoxActionPerformed

    private void roomsComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_roomsComboBoxActionPerformed

    }//GEN-LAST:event_roomsComboBoxActionPerformed

    private void sectionsComboBoxActionPerformed(java.awt.event.ActionEvent evt) {

    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AddClasses.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AddClasses.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AddClasses.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AddClasses.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AddClasses().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton CancelButton;
    private app.bolivia.swing.JCTextField ClassName;
    private javax.swing.JButton CreateButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JComboBox<String> roomsComboBox;
    private javax.swing.JComboBox<String> sectionsComboBox;
    private javax.swing.JComboBox<String> subjectsComboBox;
    // End of variables declaration//GEN-END:variables
}
